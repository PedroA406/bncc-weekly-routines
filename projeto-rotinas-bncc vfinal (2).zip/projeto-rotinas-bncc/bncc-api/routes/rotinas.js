import express from "express";
import { gerarRotina, listarRotinas, buscarRotinaPorId,
  atualizarRotina } from "../controllers/rotinaController.js";

const router = express.Router();

router.post("/gerar", gerarRotina);
router.get("/", listarRotinas);
router.get("/:id", buscarRotinaPorId);     // 👈 NOVA
router.put("/:id", atualizarRotina);       // 👈 NOVA

export default router;
