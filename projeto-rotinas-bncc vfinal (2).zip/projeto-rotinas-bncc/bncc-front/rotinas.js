document.addEventListener("DOMContentLoaded", carregarRotinas);

async function carregarRotinas() {
  const listaRotinas = document.getElementById("listaRotinas");

  if (!listaRotinas) {
    console.error("Elemento #listaRotinas não encontrado");
    return;
  }

  try {
    const res = await fetch("http://localhost:5000/api/rotinas");

    if (!res.ok) {
      throw new Error("Erro ao buscar rotinas");
    }

    const rotinas = await res.json();

    listaRotinas.innerHTML = "";

    if (!rotinas.length) {
      listaRotinas.innerHTML = `
        <section class="card">
          <p>⚠️ Nenhuma rotina criada até o momento.</p>
        </section>
      `;
      return;
    }

    rotinas.forEach((rotina) => {
      const card = document.createElement("section");
      card.className = "card";

      card.innerHTML = `
        <h2>📘 ${rotina.ano}</h2>
        <p><strong>Bimestre:</strong> ${rotina.bimestre}</p>
        <p><strong>Semana:</strong> ${rotina.semana}</p>

        <p><strong>Objetivos:</strong><br>
          ${rotina.objetivos || "—"}
        </p>

        <div style="margin-top: 12px">
          <a href="editar-rotina.html?id=${rotina._id}" class="btn primary">
            ✏️ Editar Rotina
          </a>
        </div>
      `;

      listaRotinas.appendChild(card);
    });

  } catch (err) {
    console.error(err);
    listaRotinas.innerHTML = `
      <section class="card">
        <p>❌ Erro ao carregar rotinas.</p>
      </section>
    `;
  }
}
