document.addEventListener("DOMContentLoaded", () => {
  const params = new URLSearchParams(window.location.search);
  const rotinaId = params.get("id");

  if (!rotinaId) {
    alert("Rotina não encontrada.");
    window.location.href = "rotinas.html";
    return;
  }

  carregarRotina(rotinaId);

  const form = document.getElementById("formEditarRotina");
  form.addEventListener("submit", (e) => salvarAlteracoes(e, rotinaId));
});

// 🔎 Buscar rotina
async function carregarRotina(id) {
  try {
    const res = await fetch(`http://localhost:5000/api/rotinas/${id}`);

    if (!res.ok) {
      throw new Error("Erro ao buscar rotina");
    }

    const rotina = await res.json();

    document.getElementById("rotinaId").value = rotina._id;
    document.getElementById("ano").value = rotina.ano;
    document.getElementById("bimestre").value = rotina.bimestre;
    document.getElementById("semana").value = rotina.semana;
    document.getElementById("objetivos").value = rotina.objetivos || "";
    document.getElementById("metodologia").value = rotina.metodologia || "";
    document.getElementById("recursos").value = rotina.recursos || "";
    document.getElementById("avaliacao").value = rotina.avaliacao || "";
    document.getElementById("observacoes").value = rotina.observacoes || "";

  } catch (err) {
    console.error(err);
    alert("Erro ao carregar rotina.");
    window.location.href = "rotinas.html";
  }
}

// 💾 Salvar edição
async function salvarAlteracoes(event, id) {
  event.preventDefault();

  const dados = {
    objetivos: document.getElementById("objetivos").value,
    metodologia: document.getElementById("metodologia").value,
    recursos: document.getElementById("recursos").value,
    avaliacao: document.getElementById("avaliacao").value,
    observacoes: document.getElementById("observacoes").value
  };

  try {
    const res = await fetch(`http://localhost:5000/api/rotinas/${id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(dados)
    });

    if (!res.ok) {
      throw new Error("Erro ao salvar alterações");
    }

    alert("✅ Rotina atualizada com sucesso!");
    window.location.href = "rotinas.html";

  } catch (err) {
    console.error(err);
    alert("❌ Erro ao salvar rotina.");


  }


  
}

const btnPDF = document.getElementById("btnPDF");

btnPDF.addEventListener("click", () => {
  const { jsPDF } = window.jspdf;
  const doc = new jsPDF();

  const ano = document.getElementById("ano").value;
  const bimestre = document.getElementById("bimestre").value;
  const semana = document.getElementById("semana").value;

  const objetivos = document.getElementById("objetivos").value || "—";
  const metodologia = document.getElementById("metodologia").value || "—";
  const recursos = document.getElementById("recursos").value || "—";
  const avaliacao = document.getElementById("avaliacao").value || "—";
  const observacoes = document.getElementById("observacoes").value || "—";

  // TÍTULO
  doc.setFont("Helvetica", "bold");
  doc.setFontSize(18);
  doc.text("Rotina Semanal - BNCC", 105, 15, { align: "center" });

  doc.setFont("Helvetica", "normal");
  doc.setFontSize(12);
  doc.text(`Ano: ${ano} | Bimestre: ${bimestre} | Semana: ${semana}`, 14, 30);

  doc.line(10, 36, 200, 36);

  let y = 50;

  const secoes = [
    { titulo: "Objetivos", texto: objetivos },
    { titulo: "Metodologia", texto: metodologia },
    { titulo: "Recursos", texto: recursos },
    { titulo: "Avaliação", texto: avaliacao },
    { titulo: "Observações", texto: observacoes }
  ];

  secoes.forEach(sec => {
    if (y > 250) {
      doc.addPage();
      y = 20;
    }

    doc.setFont("Helvetica", "bold");
    doc.text(`${sec.titulo}:`, 14, y);
    y += 8;

    doc.setFont("Helvetica", "normal");
    const lines = doc.splitTextToSize(sec.texto, 180);
    lines.forEach(line => {
      if (y > 270) {
        doc.addPage();
        y = 20;
      }
      doc.text(line, 14, y);
      y += 7;
    });

    y += 5;
  });

  doc.save("rotina_bncc.pdf");
});
