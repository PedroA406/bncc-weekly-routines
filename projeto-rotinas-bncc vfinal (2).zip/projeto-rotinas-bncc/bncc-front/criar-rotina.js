// ============================
// ELEMENTOS
// ============================
const form = document.getElementById("formRotina");
const statusArea = document.getElementById("statusArea");
const cards = document.getElementById("cards");

const listaHabilidades = document.getElementById("listaHabilidades");
const objetoEl = document.getElementById("objeto");
const metodologiaEl = document.getElementById("metodologia");
const recursosEl = document.getElementById("recursos");
const avaliacaoEl = document.getElementById("avaliacao");

const btnLimpar = document.getElementById("btnLimpar");
const btnPDF = document.getElementById("btnPDF");

let rotinaAtual = null;

// ============================
// FUNÇÕES AUXILIARES
// ============================
function showCards(show) {
  if (cards) {
    cards.style.display = show ? "block" : "none";
  }
}

function setStatus(msg) {
  if (statusArea) statusArea.textContent = msg;
}

// ============================
// GERAR ROTINA
// ============================
form.addEventListener("submit", async (e) => {
  e.preventDefault();

  const ano = Number(document.getElementById("ano").value);
  const bimestre = Number(document.getElementById("bimestre").value);
  const semana = Number(document.getElementById("semana").value);

  if (!ano || !bimestre || !semana) {
    setStatus("⚠️ Preencha ano, bimestre e semana.");
    return;
  }

  setStatus("⏳ Gerando rotina...");
  showCards(false);

  try {
    const res = await fetch("http://localhost:5000/api/rotinas/gerar", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ano, bimestre, semana }),
    });

    const data = await res.json();

    if (!res.ok) {
      setStatus(data.message || "Erro ao gerar rotina.");
      return;
    }

    rotinaAtual = data.rotina || data;

    // ============================
    // PREENCHER DADOS
    // ============================
    listaHabilidades.innerHTML = "";

    (rotinaAtual.habilidades || []).forEach((h) => {
      const li = document.createElement("li");
      li.textContent =
        (h.codigo ? h.codigo + " — " : "") +
        (h.descricao || h.nome || h);
      listaHabilidades.appendChild(li);
    });

    objetoEl.textContent = rotinaAtual.objetivos || "—";
    metodologiaEl.textContent = rotinaAtual.metodologia || "—";
    recursosEl.textContent = rotinaAtual.recursos || "—";
    avaliacaoEl.textContent = rotinaAtual.avaliacao || "—";

    setStatus("✅ Rotina gerada com sucesso.");
    showCards(true);

  } catch (err) {
    console.error(err);
    setStatus("❌ Erro de conexão ao gerar rotina.");
  }
});

// ============================
// LIMPAR FORMULÁRIO
// ============================
btnLimpar.addEventListener("click", () => {
  document.getElementById("ano").value = "";
  document.getElementById("bimestre").value = "";
  document.getElementById("semana").value = "";

  setStatus("Campos limpos.");
  showCards(false);
  rotinaAtual = null;
});

// ============================
// GERAR PDF
// ============================
btnPDF.addEventListener("click", () => {
  if (!rotinaAtual) {
    alert("Nenhuma rotina gerada.");
    return;
  }

  const { jsPDF } = window.jspdf;
  const doc = new jsPDF();

  const escola = document.getElementById("escola").value || "—";
  const professor = document.getElementById("professor").value || "—";
  const periodo = document.getElementById("periodo").value || "—";

  // TÍTULO
  doc.setFont("Helvetica", "bold");
  doc.setFontSize(18);
  doc.text("Rotina Semanal - BNCC", 105, 15, { align: "center" });

  doc.setFont("Helvetica", "normal");
  doc.setFontSize(12);
  doc.text(`Escola: ${escola}`, 14, 30);
  doc.text(`Professor: ${professor}`, 14, 38);
  doc.text(`Período: ${periodo}`, 14, 46);

  doc.line(10, 52, 200, 52);

  let y = 65;

  // HABILIDADES
  doc.setFont("Helvetica", "bold");
  doc.setFontSize(14);
  doc.text("Habilidades:", 14, y);
  y += 8;

  doc.setFont("Helvetica", "normal");
  doc.setFontSize(12);

  const habilidades = Array.from(
    document.querySelectorAll("#listaHabilidades li")
  ).map((li) => li.textContent.trim());

  habilidades.forEach((hab) => {
    const lines = doc.splitTextToSize("- " + hab, 180);
    lines.forEach((line) => {
      if (y > 270) {
        doc.addPage();
        y = 20;
      }
      doc.text(line, 14, y);
      y += 7;
    });
  });

  y += 5;

  // OUTRAS SEÇÕES
  const secoes = [
    { titulo: "Objeto", el: objetoEl },
    { titulo: "Metodologia", el: metodologiaEl },
    { titulo: "Recursos", el: recursosEl },
    { titulo: "Avaliação", el: avaliacaoEl },
  ];

  secoes.forEach((sec) => {
    if (y > 250) {
      doc.addPage();
      y = 20;
    }

    doc.setFont("Helvetica", "bold");
    doc.setFontSize(14);
    doc.text(`${sec.titulo}:`, 14, y);
    y += 8;

    doc.setFont("Helvetica", "normal");
    doc.setFontSize(12);

    const lines = doc.splitTextToSize(sec.el.textContent || "—", 180);
    lines.forEach((line) => {
      if (y > 270) {
        doc.addPage();
        y = 20;
      }
      doc.text(line, 14, y);
      y += 7;
    });

    y += 5;
  });

  doc.save("rotina_bncc.pdf");
});
