import mongoose from "mongoose";
import dotenv from "dotenv";
import fs from "fs";
import path from "path";
import connectDB from "./config/db.js";
import Habilidade from "./models/Habilidade.js";

dotenv.config();

const __dirname = path.resolve();

const seedHabilidades = async () => {
  try {
    await connectDB();
    console.log("✅ Conectado ao MongoDB");

    // Limpa a coleção de habilidades antes de inserir novas
    await Habilidade.deleteMany();
    console.log("🧹 Coleção 'Habilidades' limpa com sucesso!");

    // Lê os dois arquivos JSON (6º e 7º ano)
    const habilidades6 = JSON.parse(
      fs.readFileSync(path.join(__dirname, "habilidades6.json"))
    );
    const habilidades7 = JSON.parse(
      fs.readFileSync(path.join(__dirname, "habilidades7.json"))
    );

    // Une os dois conjuntos de habilidades
    const todasHabilidades = [...habilidades6, ...habilidades7];

    // Insere tudo no banco
    await Habilidade.insertMany(todasHabilidades);
    console.log(`🎯 ${todasHabilidades.length} habilidades inseridas com sucesso!`);

    process.exit(0);
  } catch (error) {
    console.error("❌ Erro ao popular habilidades:", error);
    process.exit(1);
  }
};

seedHabilidades();
