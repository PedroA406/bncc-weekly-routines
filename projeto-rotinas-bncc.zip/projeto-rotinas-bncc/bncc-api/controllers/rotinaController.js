import Rotina from "../models/Rotina.js";
import Habilidade from "../models/Habilidade.js";

// Gerar rotina automática
export const gerarRotina = async (req, res) => {
  const { ano, bimestre, semana } = req.body;
  const habilidades = await Habilidade.find({ ano }).skip((semana - 1) * 2).limit(2); // 2 habilidades por semana (ajustável)

  const novaRotina = await Rotina.create({
    ano,
    bimestre,
    semana,
    habilidades,
    objetivos: "Desenvolver o raciocínio lógico e matemático.",
    metodologia: "Aulas dialogadas, resolução de problemas e atividades práticas.",
    recursos: "Quadro, caderno e material digital.",
    avaliacao: "Participação e resolução de atividades.",
    observacoes: "Rotina gerada automaticamente."
  });

  res.status(201).json(novaRotina);
};

// Listar todas as rotinas
export const listarRotinas = async (req, res) => {
  const rotinas = await Rotina.find().populate("habilidades");
  res.json(rotinas);
};
