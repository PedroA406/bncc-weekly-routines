import mongoose from "mongoose";
import dotenv from "dotenv";
import fs from "fs";
import path from "path";
import Rotina from "./models/Rotina.js";
import Habilidade from "./models/Habilidade.js";
import connectDB from "./config/db.js";

dotenv.config();

const __dirname = path.resolve();

const seedRotinas = async () => {
  try {
    await connectDB();
    console.log("✅ Conectado ao MongoDB");

    // Limpar coleções antes de popular
    await Rotina.deleteMany();
    console.log("🧹 Rotinas removidas com sucesso!");

    // Ler arquivos de habilidades
    const habilidades6 = JSON.parse(
      fs.readFileSync(path.join(__dirname, "habilidades6.json"))
    );
    const habilidades7 = JSON.parse(
      fs.readFileSync(path.join(__dirname, "habilidades7.json"))
    );

    // Buscar habilidades salvas no banco
    const habilidadesDB = await Habilidade.find();
    if (!habilidadesDB.length) {
      console.log("⚠️ Nenhuma habilidade encontrada! Execute primeiro: node seedHabilidades.js");
      process.exit(0);
    }

    // Agrupar habilidades por ano
    const habilidades6DB = habilidadesDB.filter(h => h.ano === "6º ano");
    const habilidades7DB = habilidadesDB.filter(h => h.ano === "7º ano");

    // Função para criar rotinas automáticas
    const gerarRotinasPorAno = async (ano, habilidades) => {
      const totalBimestres = 4;
      const habilidadesPorSemana = 2;
      const semanasPorBimestre = Math.ceil(habilidades.length / (habilidadesPorSemana * totalBimestres));

      let rotinaCount = 0;

      for (let bimestre = 1; bimestre <= totalBimestres; bimestre++) {
        for (let semana = 1; semana <= semanasPorBimestre; semana++) {
          const inicio = rotinaCount * habilidadesPorSemana;
          const fim = inicio + habilidadesPorSemana;
          const habilidadesSemana = habilidades.slice(inicio, fim).map(h => h._id);

          if (habilidadesSemana.length === 0) break;

          await Rotina.create({
            ano,
            bimestre,
            semana,
            habilidades: habilidadesSemana,
            objetivos: "Desenvolver competências matemáticas conforme a BNCC.",
            metodologia: "Aulas expositivas, atividades práticas e resolução de problemas.",
            recursos: "Quadro, caderno, calculadora e recursos digitais.",
            avaliacao: "Participação, atividades e desempenho nas avaliações.",
            observacoes: "Rotina gerada automaticamente a partir das habilidades da BNCC."
          });

          rotinaCount++;
        }
      }

      console.log(`✅ ${rotinaCount} rotinas criadas para o ${ano}.`);
    };

    await gerarRotinasPorAno("6º ano", habilidades6DB);
    await gerarRotinasPorAno("7º ano", habilidades7DB);

    console.log("🎯 Rotinas geradas com sucesso!");
    process.exit(0);

  } catch (error) {
    console.error("❌ Erro ao gerar rotinas:", error);
    process.exit(1);
  }
};

seedRotinas();
