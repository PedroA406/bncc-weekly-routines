# bncc-weekly-routines
Roninas semanais de aula de acordo com as habilidades da bncc e com sugestões de atividades, metodologia e avaliações
